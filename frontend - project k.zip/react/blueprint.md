# Project Blueprint

## Overview

This project is a chatbot application built with React. It features a chat interface that uses the Gemini API to generate responses.

## Features

*   **Gemini Integration:**
    *   The chatbot uses the Gemini API to generate responses to user messages.
    *   The Gemini API key is hardcoded in the application.
    *   **Model:** `gemini-1.5-flash`
*   **Chat Interface:**
    *   A chat interface allows users to send messages and see responses from the Gemini API.
    *   The chat history is stored in the component's local state and is not persisted.
*   **Styling:**
    *   The application is styled using Material-UI, providing a clean and modern user interface.
    *   Custom styles are applied to create a unique and visually appealing design.

## Project Structure

*   **`src/`**
    *   **`pages/`**
        *   **`ChatbotPage.jsx`**: The main chat interface where users can send and receive messages.
    *   **`App.jsx`**: The main application component that sets up routing.
    *   **`index.css`**: Global styles for the application.
    *   **`main.jsx`**: The entry point of the application.
*   **`package.json`**: Lists the project dependencies and scripts.
