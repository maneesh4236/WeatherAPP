// import { Router, Routes, Route } from "react-router-dom";
// import LoginPage from "./Login/Login";
// import SignupPage from "./Signup/Signup";
// import ChatbotPage from "./Chatbotpage/ChatbotPage";

// function App() {
//   return (
//     <Router>
//       <Routes>
//         <Route path="/" element={<LoginPage />} />
//         <Route path="/login" element={<LoginPage />} />
//         <Route path="/signup" element={<SignupPage />} />
//         <Route path="/chat" element={<ChatbotPage />} />
//       </Routes>
//     </Router>
//   );
// }

// export default App;


import React from "react";
import { Routes, Route, Navigate } from "react-router-dom";
import LoginPage from "./Login/Login";
import SignupPage from "./Signup/Signup";
import ChatbotPage from "./Chatbotpage/ChatbotPage";


function App() {
  return (
    <Routes>
      {/* Redirect root `/` to login */}
      <Route path="/" element={<Navigate to="/login" />} />

      {/* Auth pages */}
      <Route path="/login" element={<LoginPage />} />
      <Route path="/signup" element={<SignupPage />} />

      {/* Chatbot */}
      <Route path="/chat" element={<ChatbotPage />} />

      {/* Catch all unknown routes */}
      <Route path="*" element={<h2 style={{ textAlign: "center" }}>404 - Page Not Found</h2>} />
    </Routes>
  );
}

export default App;
