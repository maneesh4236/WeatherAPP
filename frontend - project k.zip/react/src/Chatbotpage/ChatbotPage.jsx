import React, { useEffect, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import ReactMarkdown from "react-markdown";
import { Prism as SyntaxHighlighter } from "react-syntax-highlighter";
import { darcula } from "react-syntax-highlighter/dist/cjs/styles/prism";

// ❌ Replace with your real Gemini API key
// const genAI = new GoogleGenerativeAI("AIzaSyDUvh-jm3I7Vlbp1ziaNlOXgAFYp1eWmJk");

function ChatbotPage() {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");
  const [isSending, setIsSending] = useState(false);
  const scrollRef = useRef(null);
  const navigate = useNavigate();

  const userId = localStorage.getItem("user_id");

  // Auto scroll
  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  // ✅ Load this user's chat history on login
  useEffect(() => {
    if (userId) {
      const fetchChatHistory = async () => {
        try {
          const response = await fetch(`http://127.0.0.1:8000/api/users/${userId}/queries/`);
          if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
          }
          const data = await response.json();
          const formattedMessages = data.flatMap((item) => [
            {
              id: item.id * 2, // Unique ID for question
              text: item.question,
              sender: "me",
              timestamp: formatTime(), // You might want to get actual timestamp from backend
            },
            {
              id: item.id * 2 + 1, // Unique ID for answer
              text: item.answer,
              sender: "bot",
              timestamp: formatTime(), // You might want to get actual timestamp from backend
            },
          ]);
          setMessages(formattedMessages);
        } catch (error) {
          console.error("Error fetching chat history:", error);
        }
      };
      fetchChatHistory();
    } else {
      setMessages([]); // Clear messages if no user is logged in
    }
  }, [userId]);

  // ✅ Save this user's chat history whenever messages update
  useEffect(() => {
    if (userId) {
      localStorage.setItem(
        `chatHistory_${userId}`,
        JSON.stringify(messages)
      );
    }
  }, [messages, userId]);

  const formatTime = () => {
    const now = new Date();
    return now.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
  };

  // Helper function to extract language from code block
  const extractLanguage = (className) => {
    const languageClass = className.find((name) => name.startsWith("language-"));
    return languageClass ? languageClass.substring(9) : "plaintext";
  };

  const handleSend = async (e) => {
    e.preventDefault();
    if (!input.trim()) return;

    const userMessage = {
      id: Date.now(),
      text: input,
      sender: "me",
      timestamp: formatTime(),
    };

    setMessages((prev) => [...prev, userMessage]);
    setInput("");
    setIsSending(true);

    try {
      // const model = genAI.getGenerativeModel({ model: "gemini-1.5-flash" });
      // const result = await model.generateContent(input);
      // const botResponse = await result.response.text();

      const response = await fetch("http://127.0.0.1:8000/chat", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          user_id: userId,
          query: input,
        }),
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();
      const botResponse = String(data.response); // Ensure botResponse is a string

      const botMessage = {
        id: Date.now() + 1,
        text: botResponse,
        sender: "bot",
        timestamp: formatTime(),
      };

      setMessages((prev) => [...prev, botMessage]);
    } catch (error) {
      console.error("Error:", error);
      setMessages((prev) => [
        ...prev,
        {
          id: Date.now() + 1,
          text: "⚠️ Sorry, something went wrong. Please try again.",
          sender: "bot",
          timestamp: formatTime(),
        },
      ]);
    } finally {
      setIsSending(false);
    }
  };

  const handleSignOut = () => {
    localStorage.removeItem("currentUser");
    localStorage.removeItem("user_id"); // Remove user_id as well
    navigate("/login");
  };

  return (
    <div className="d-flex vh-100 bg-light">
      {/* Sidebar */}
      <div className="border-end bg-white p-3" style={{ width: "260px" }}>
        <h6 className="mb-3">💬 {localStorage.getItem("currentUser")}’s History</h6>
        {messages.length === 0 ? (
          <p className="text-muted">No chats yet</p>
        ) : (
          <ul className="list-unstyled">
            {messages.map((msg) => (
              <li
                key={msg.id}
                className="chat-preview p-2 mb-2 rounded border"
              >
                <div className="d-flex align-items-center">
                  <span className="me-2">
                    {msg.sender === "me" ? "👤" : "🤖"}
                  </span>
                  <div className="flex-grow-1">
                    <div className="fw-bold small text-truncate">
                      {(msg.text || "").slice(0, 25)}
                    </div>
                    <div className="text-muted small">{msg.timestamp}</div>
                  </div>
                </div>
              </li>
            ))}
          </ul>
        )}
      </div>

      {/* Chat Area */}
      <div className="d-flex flex-column flex-grow-1">
        <div className="d-flex justify-content-between align-items-center p-3 border-bottom bg-white">
          <h5 className="mb-0">Drive Verse</h5>
          <button className="btn btn-outline-danger" onClick={handleSignOut}>
            Sign Out
          </button>
        </div>

        {/* Messages */}
        <div className="flex-grow-1 overflow-auto p-3" ref={scrollRef}>
          {messages.length === 0 ? (
            <div className="text-center text-muted mt-5">
              <h4>🤖 How can I help you today?</h4>
              <p>I’m your AI assistant powered by Gemini.</p>
            </div>
          ) : (
            messages.map((msg) => (
              <div
                key={msg.id}
                className={`d-flex mb-3 ${
                  msg.sender === "me"
                    ? "justify-content-end"
                    : "justify-content-start"
                }`}
              >
                <div
                  className={`chat-bubble ${
                    msg.sender === "me" ? "chat-bubble-me" : "chat-bubble-bot"
                  }`}
                >
                  <ReactMarkdown
                    children={msg.text}
                    components={{
                      code({ node, inline, className, children, ...props }) {
                        const match = /language-(\w+)/.exec(className || "");
                        return !inline && match ? (
                          <SyntaxHighlighter
                            children={String(children).replace(/\\n$/, "")}
                            style={darcula}
                            language={match[1]}
                            PreTag="div"
                            {...props}
                          />
                        ) : (
                          <code className={className} {...props}>
                            {children}
                          </code>
                        );
                      },
                      li: ({ children }) => (
                        <li>
                          <span className="bullet-point"></span>
                          {children}
                        </li>
                      ),
                    }}
                  />
                  <small className="chat-timestamp">{msg.timestamp}</small>
                </div>
              </div>
            ))
          )}

          {/* Typing indicator */}
          {isSending && (
            <div className="d-flex mb-3 justify-content-start">
              <div className="chat-bubble chat-bubble-bot">
                <div className="typing-dots">
                  <span></span>
                  <span></span>
                  <span></span>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Input */}
        <form onSubmit={handleSend} className="d-flex border-top p-3 bg-white">
          <input
            type="text"
            className="form-control me-2"
            placeholder="Type a message..."
            value={input}
            onChange={(e) => setInput(e.target.value)}
            disabled={isSending}
          />
          <button type="submit" className="btn btn-primary" disabled={isSending}>
            {isSending ? "..." : "Send"}
          </button>
        </form>
      </div>
    </div>
  );
}

export default ChatbotPage;
